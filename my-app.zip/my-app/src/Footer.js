import React, {Component} from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem } from 'reactstrap'
  import './App.css';
class Footer extends Component {
  render() {
    return (
       <div className="footer">
            <p>Footer</p>
       </div>
    )
  }
}

export default Footer;